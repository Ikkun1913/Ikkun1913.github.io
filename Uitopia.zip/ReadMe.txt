このzipファイルはしぐれういさんの7周年記念(2026年)企画展"しぐれうい展2026｢Uitopia｣"のグッズにある、"Uitopia.zip（CATALOG）"をオマージュしたzipファイルです。
このzipファイル内にある、インターネット ショートカット (.url)はそのグッズへの直リンです。

リンク↓
https://uishigure-event.booth.pm/items/8151115

以下、しぐれうい展2026「Uitopia」のサイトに載っていた、クレジットです
CREDIT
主催:
しぐれうい・INCOLORE

プロデュース:
しぐれうい・RICOL

アートディレクション・クリエイティブ制作:
RICOL

協力:
ピクシブ株式会社